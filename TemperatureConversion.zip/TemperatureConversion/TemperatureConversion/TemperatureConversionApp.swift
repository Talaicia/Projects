//
//  TemperatureConversionApp.swift
//  TemperatureConversion
//
//  Created by Talaicia Isaacs on 6/21/24.
//

import SwiftUI

@main
struct TemperatureConversionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
