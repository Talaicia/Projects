//
//  RockPaperScissorsApp.swift
//  RockPaperScissors
//
//  Created by Talaicia Isaacs on 6/25/24.
//

import SwiftUI

@main
struct RockPaperScissorsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
