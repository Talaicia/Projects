//
//  GuessTheFlagApp.swift
//  GuessTheFlag
//
//  Created by Talaicia Isaacs on 6/24/24.
//

import SwiftUI

@main
struct GuessTheFlagApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
